<?php

return array(
			'host' => 'localhost',
			'dbname' => 'bejee',
			'user' => 'root',
			'password' => '',
);