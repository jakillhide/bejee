<?php
return array(

	'auth' => 'auth/index', 
	'tasks' => 'tasks/index', 

	);